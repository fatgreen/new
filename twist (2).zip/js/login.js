$(function(){
            roomid = $("#roomid").val();
            username = $("#username").val();

            $("#open-room").on("click",function(){
               jump1();
            });
        });

        function jump1(){
            url = "main.html?room-id="+roomid+"&username="+username;//此處拼接內容
            window.location.href = url;
        }